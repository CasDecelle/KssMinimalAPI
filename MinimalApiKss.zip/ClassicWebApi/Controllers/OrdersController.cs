﻿using System.ComponentModel.DataAnnotations;

namespace ClassicWebApi.Controllers;

[Route("orders")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orderService;
    private readonly IValidator<OrderDto> _validator;

    public OrdersController(IOrderService orderService, IValidator<OrderDto> validator)
	{
        _orderService = orderService;
        _validator = validator;

    }

    [HttpGet("{customerId}")]
    [ProducesResponseType(200, Type = typeof(IEnumerable<OrderDto>))]
    public async Task<IActionResult> GetOrders(Guid customerId)
    {
        var orders = await _orderService.GetByCustomerId(customerId);

        return Ok(orders);
    }

    [HttpPost("")]
    [ProducesResponseType(400, Type = typeof(IEnumerable<string>))]
    [ProducesResponseType(200, Type = typeof(OrderDto))]
    public async Task<IActionResult> Handle(OrderDto order)
    {
        var validationResult = _validator.Validate(order);

        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => e.ErrorMessage);
            return BadRequest(errors);
        }

        var addedOrder = await _orderService.Add(order);

        return Ok(addedOrder);
    }
}
