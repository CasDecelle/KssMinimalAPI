﻿namespace ClassicWebApi.Controllers;

[Route("carts")]
public class ShoppingCartsController : ControllerBase
{
	private readonly IShoppingCartService _shoppingCartService;
	private readonly IValidator<ShoppingCartDto> _validator;
	public ShoppingCartsController(IShoppingCartService shoppingCartService, IValidator<ShoppingCartDto> validator)
	{
		_shoppingCartService = shoppingCartService;
        _validator = validator;
	}

	[HttpGet("{customerId}")]
    [ProducesResponseType(404)]
    [ProducesResponseType(200, Type = typeof(ShoppingCartDto))]
    public async Task<IActionResult> GetShoppingCartByCustomerId(Guid customerId)
    {
        var shoppingCart = await _shoppingCartService.Get(customerId);

        if (shoppingCart == null)
        {
            return NotFound();
        }

        return Ok(shoppingCart);
    }

    [HttpPost("")]
    [ProducesResponseType(400, Type = typeof(IEnumerable<string>))]
    [ProducesResponseType(200, Type = typeof(ShoppingCartDto))]
    public async Task<IActionResult> PostShoppingCart(ShoppingCartDto cart)
    {
        var validationResult = _validator.Validate(cart);

        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => e.ErrorMessage);
            return BadRequest(errors);
        }

        var shoppingCart = await _shoppingCartService.Add(cart);

        return Ok(shoppingCart);
    }

    [HttpPut("")]
    [ProducesResponseType(400, Type = typeof(IEnumerable<string>))]
    [ProducesResponseType(204)]
    public async Task<IActionResult> Handle(ShoppingCartDto cart)
    {
        var validationResult = _validator.Validate(cart, options => options.IncludeRuleSets(RuleSets.PutShoppingCart));

        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => e.ErrorMessage);
            return BadRequest(errors);
        }

        await _shoppingCartService.Update(cart);

        return NoContent();
    }
}
