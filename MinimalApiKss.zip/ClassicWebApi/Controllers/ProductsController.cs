﻿using Data.Entities;

namespace ClassicWebApi.Controllers;

[Route("products")]
public class ProductsController : ControllerBase
{
	private readonly IProductService _productService;

    public ProductsController(IProductService productService)
	{
        _productService = productService;
    }

	[HttpGet("")]
    [ProducesResponseType(200, Type = typeof(IEnumerable<ProductDto>))]
    public async Task<IActionResult> GetProducts()
	{
        var products = await _productService.Get();
        return Ok(products);
    }

    [HttpGet("{productId}")]
    [ProducesResponseType(404, Type = typeof(ProductDto))]
    [ProducesResponseType(200, Type = typeof(ProductDto))]
    public async Task<IActionResult> GetProduct(Guid productId)
    {
        var product = await _productService.Get(productId);

        if (product == null)
        {
            return NotFound();
        }
        return Ok(product);
    }
}
