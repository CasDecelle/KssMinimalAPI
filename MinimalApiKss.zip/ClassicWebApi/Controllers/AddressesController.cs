﻿namespace ClassicWebApi.Controllers;

[Route("addresses")]
public class AddressesController : ControllerBase
{
    private readonly IAddressService _addressService;

    public AddressesController(IAddressService addressService)
    {
        _addressService = addressService;
    }

    [HttpPost("")]
    [ProducesResponseType(200, Type = typeof(AddressDto))]
    public async Task<IActionResult> PostAddress(AddressDto address)
    {
        var addedAddress = await _addressService.Add(address);
        return Ok(addedAddress);
    }
}
