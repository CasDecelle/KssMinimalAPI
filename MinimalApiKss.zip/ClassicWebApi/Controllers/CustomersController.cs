namespace ClassicWebApi.Controllers;

[Route("customers")]
public class CustomersController : ControllerBase
{
    private readonly ICustomerService _customerService;
    private readonly IAddressService _addressService;

    public CustomersController(ICustomerService customerService, IAddressService addressService)
    {
        _customerService = customerService;
        _addressService = addressService;
    }

    [HttpGet("{customerId}")]
    [ProducesResponseType(404)]
    [ProducesResponseType(200, Type = typeof(CustomerDto))]
    public async Task<IActionResult> GetCustomer(Guid customerId)
    {
        var customer = await _customerService.GetCustomer(customerId);

        if (customer is null)
            NotFound();

        return Ok(customer);
    }

    [HttpPost("")]
    [ProducesResponseType(200, Type = typeof(CustomerDto))]
    public async Task<IActionResult> PostCustomer(CustomerDto customer)
    {
        var postedCustomer = await _customerService.AddCustomer(customer);
        return Ok(postedCustomer);
    }
}