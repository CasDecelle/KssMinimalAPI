﻿global using Data;
global using Data.Entities;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.AspNetCore.Mvc;
global using FluentValidation;
global using ClassicWebApi.Common;
global using ClassicWebApi.Dtos;
global using ClassicWebApi.Services;
global using ClassicWebApi.Mappings;
global using ClassicWebApi.Infrastructure;
global using ClassicWebApi.Validation;


