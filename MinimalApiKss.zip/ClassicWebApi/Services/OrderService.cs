﻿namespace ClassicWebApi.Services;

public interface IOrderService
{
    Task<IEnumerable<OrderDto>> GetByCustomerId(Guid customerId);
    Task<OrderDto> Add(OrderDto order);
}

public class OrderService : IOrderService
{
    private readonly DatabaseContext _context;
    private readonly IDateTimeProvider _dateTimeProvider;

    public OrderService(DatabaseContext context, IDateTimeProvider dateTimeProvider)
    {
        _context = context;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task<IEnumerable<OrderDto>> GetByCustomerId(Guid customerId)
    {
        var orders = await _context.Orders.Where(o => o.ShoppingCart.CustomerId == customerId).ToListAsync();
            
        return orders.Select(o => o.MapToDto());
    }

    public async Task<OrderDto> Add(OrderDto order)
    {
        order.CreatedAt = _dateTimeProvider.UtcNow;
        var orderEntity = order.MapToEntity();

        var addedOrder = _context.Add(orderEntity);
        await _context.SaveChangesAsync();

        return addedOrder.Entity.MapToDto();
    }
}
