﻿namespace ClassicWebApi.Services;

public interface ICustomerService
{
    Task<CustomerDto> GetCustomer(Guid id);
    Task<CustomerDto> AddCustomer(CustomerDto customer);
}

public class CustomerService : ICustomerService
{
    private readonly DatabaseContext _context;

    public CustomerService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<CustomerDto> GetCustomer(Guid id)
    {
        var customer = await _context.Customers.FirstAsync(c => c.Id == id);

        return customer.MapToDto();
    }

    public async Task<CustomerDto> AddCustomer(CustomerDto customer)
    {
        var addedCustomer = _context.Add(customer.MapToEntity());
        await _context.SaveChangesAsync();

        return addedCustomer.Entity.MapToDto();
    }
}
