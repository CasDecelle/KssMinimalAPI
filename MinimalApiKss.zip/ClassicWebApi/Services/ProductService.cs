﻿namespace ClassicWebApi.Services;

public interface IProductService
{
    Task<IEnumerable<ProductDto>> Get();
    Task<ProductDto> Get(Guid id);
}

public class ProductService : IProductService
{
    private readonly DatabaseContext _context;

    public ProductService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<ProductDto>> Get()
    {
        var products = await _context.Products.ToListAsync();
        return products.Select(product => product.MapToDto());
    }

    public async Task<ProductDto> Get(Guid id)
    {
        var product = await _context.Products.SingleAsync(product => product.Id == id);
        return product.MapToDto();
    }
}
