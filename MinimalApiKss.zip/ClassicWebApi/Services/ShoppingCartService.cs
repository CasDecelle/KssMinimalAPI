﻿namespace ClassicWebApi.Services;

public interface IShoppingCartService
{
    Task<ShoppingCartDto> Get(Guid customerId);
    Task<ShoppingCartDto> Add(ShoppingCartDto shoppingCart);
    Task Update(ShoppingCartDto shoppingCart);
}

public class ShoppingCartService : IShoppingCartService
{
    private readonly DatabaseContext _context;
    private readonly IDateTimeProvider _dateTimeProvider;

    public ShoppingCartService(DatabaseContext context, IDateTimeProvider dateTimeProvider)
    {
        _context = context;
        _dateTimeProvider = dateTimeProvider;
    }

    public async Task<ShoppingCartDto> Get(Guid customerId)
    {
        var shoppingCart = await _context.ShoppingCarts.SingleAsync(c => c.CustomerId == customerId);
        return shoppingCart.MapToDto();
    }

    public async Task<ShoppingCartDto> Add(ShoppingCartDto shoppingCart)
    {
        shoppingCart.CreatedAt = _dateTimeProvider.UtcNow;

        var addedShoppingCart = _context.Add(shoppingCart.MapToEntity());
        await _context.SaveChangesAsync();
        return addedShoppingCart.Entity.MapToDto();
    }

    public async Task Update(ShoppingCartDto shoppingCart)
    {
        _context.Update(shoppingCart.MapToEntity());
        await _context.SaveChangesAsync();
        return;
    }
}
