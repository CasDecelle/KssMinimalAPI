﻿namespace ClassicWebApi.Dtos;

public class ShoppingCartDto
{
    public Guid? Id { get; init; }
    public DateTime? CreatedAt { get; set; }
    public Guid? CustomerId { get; init; }
    public IEnumerable<ProductDto>? Products { get; init; }
}
