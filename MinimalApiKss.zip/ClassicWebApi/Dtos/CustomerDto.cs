﻿namespace ClassicWebApi.Dtos;

public class CustomerDto
{
    public Guid? Id { get; init; }
    public string? FirstName { get; init; }
    public string? LastName { get; init; }
    public IEnumerable<AddressDto>? Addresses { get; init; }

}
