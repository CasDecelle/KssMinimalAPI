﻿namespace ClassicWebApi.Dtos;

public class OrderDto
{
    public Guid? Id { get; init; }
    public DateTime? CreatedAt { get; set; }
    public AddressDto? ShippingAddress { get; init; }
    public AddressDto? InvoiceAddress { get; init; }
    public PaymentMethod? PaymentMethod { get; init; }
    public ShoppingCartDto? ShoppingCart { get; init; }
}
