﻿namespace ClassicWebApi.Validation;

internal class RuleSets
{
    internal const string PutShoppingCart = "PutShoppingCart";
}
