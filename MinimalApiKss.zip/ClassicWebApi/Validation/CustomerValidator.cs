﻿namespace ClassicWebApi.Validation;

public class CustomerValidator : AbstractValidator<CustomerDto>
{
	public CustomerValidator()
	{
		RuleFor(customer => customer.FirstName)
			.NotEmpty().WithMessage("FirstName can not be empty")
			.MaximumLength(50).WithMessage("FirstName has a max length of 50");

        RuleFor(customer => customer.LastName)
            .NotEmpty().WithMessage("LastName can not be empty")
            .MaximumLength(50).WithMessage("LastName has a max length of 50");
    }
}
