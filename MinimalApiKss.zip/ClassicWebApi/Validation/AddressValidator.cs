﻿namespace ClassicWebApi.Validation;

public class AddressValidator : AbstractValidator<AddressDto>
{
	public AddressValidator()
	{
		RuleFor(address => address.Country)
            .NotEmpty().WithMessage("Country can not be empty")
            .MaximumLength(56).WithMessage("Country has a maximum length of 56");

        RuleFor(address => address.City)
            .NotEmpty().WithMessage("City can not be empty")
            .MaximumLength(85).WithMessage("City has a maximum length of 85");

        RuleFor(address => address.PostalCode)
            .NotEmpty().WithMessage("PostalCode can not be empty")
            .MaximumLength(12).WithMessage("PostalCode has a maximum length of 12");

        RuleFor(address => address.Street)
            .NotEmpty().WithMessage("Street can not be empty")
            .MaximumLength(100).WithMessage("Street has a maximum length of 100");

        RuleFor(address => address.Number)
            .NotEmpty().WithMessage("Number can not be empty")
            .MaximumLength(10).WithMessage("Number has a maximum length of 10");

        RuleFor(address => address.Box)
            .MaximumLength(10).WithMessage("Number has a maximum length of 10");

        RuleFor(address => address.CustomerId)
            .NotEmpty()
            .WithMessage("An address must have a customer id");
    }
}
