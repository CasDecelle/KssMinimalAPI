﻿namespace ClassicWebApi.Mappings;

public static class AddressMapping
{
    public static Address MapToEntity(this AddressDto dto)
    {
        return new Address
        {
            Id = dto.Id ?? Guid.Empty,
            Country = dto.Country!,
            City = dto.City!,
            PostalCode = dto.PostalCode!,
            Street = dto.Street!,
            Number = dto.Number!,
            Box = dto.Box,
            CustomerId = dto.CustomerId!.Value,
        };
    }

    public static AddressDto MapToDto(this Address entity)
    {
        return new AddressDto
        {
            Id = entity.Id,
            Country = entity.Country,
            City = entity.City,
            PostalCode = entity.PostalCode,
            Street = entity.Street,
            Number = entity.Number,
            Box = entity.Box,
            CustomerId = entity.CustomerId
        };
    }
}
