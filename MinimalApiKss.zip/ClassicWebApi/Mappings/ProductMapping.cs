﻿namespace ClassicWebApi.Mappings;

public static class ProductMapping
{
    public static Product MapToEntity(this ProductDto dto)
    {
        return new Product
        {
            Id = dto.Id,
        };
    }

    public static ProductDto MapToDto(this Product entity)
    {
        return new ProductDto
        {
            Id = entity.Id,
        };
    }
}
