﻿namespace ClassicWebApi.Mappings;

public static class OrderMapping
{
    public static Order MapToEntity(this OrderDto dto)
    {
        return new Order
        {
            Id = dto.Id ?? Guid.Empty,
            CreatedAt = dto.CreatedAt!.Value,
            ShoppingCartId = dto.ShoppingCart!.Id!.Value,
            InvoiceAddressId = dto.InvoiceAddress!.Id!.Value,
            ShippingAddressId = dto.ShippingAddress!.Id!.Value,
            PaymentMethodId = dto.PaymentMethod!.Id,
        };
    }

    public static OrderDto MapToDto(this Order entity)
    {
        return new OrderDto
        {
            Id = entity.Id,
            CreatedAt = entity.CreatedAt,
            ShoppingCart = entity.ShoppingCart.MapToDto(),
            InvoiceAddress = entity.InvoiceAddress.MapToDto(),
            ShippingAddress = entity.ShippingAddress.MapToDto(),
            PaymentMethod = entity.PaymentMethod,
        };
    }
}
