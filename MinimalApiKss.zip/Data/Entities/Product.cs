﻿namespace Data.Entities;

public class Product
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid Id { get; set; }

    [Required, MaxLength(100)]
    public string Name { get; set; } = null!;

    [Required, Range(0, double.PositiveInfinity)]
    public decimal Price { get; set; }

    [Required, MaxLength(100)]
    public string Company { get; set; } = null!;

    [Required, MaxLength(50)]
    public string Category { get; set; } = null!;
}
