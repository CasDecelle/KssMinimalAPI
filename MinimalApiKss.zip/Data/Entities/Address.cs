﻿namespace Data.Entities;

public class Address
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid Id { get; set; }

    [Required]
    [MaxLength(56)]
    public string Country { get; set; } = null!;

    [Required]
    [MaxLength(85)]
    public string City { get; set; } = null!;

    [Required]
    [MaxLength(12)]
    public string PostalCode { get; set; } = null!;

    [Required]
    [MaxLength(100)]
    public string Street { get; set; } = null!;

    [Required]
    [MaxLength(10)]
    public string Number { get; set; } = null!;

    [MaxLength(10)]
    public string? Box { get; set; }

    [ForeignKey("Customer")]
    public Guid CustomerId { get; set; }

    public virtual Customer Customer { get; set; } = null!;
}
