﻿namespace Data.Entities;

public class PaymentMethod
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
    public int Id { get; set; }
    public string Value { get; set; } = null!;
}
