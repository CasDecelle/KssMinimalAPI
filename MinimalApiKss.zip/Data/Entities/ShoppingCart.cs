﻿namespace Data.Entities;

public class ShoppingCart
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid Id { get; set; }

    [Required]
    public DateTime CreatedAt { get; set; }

    [Required, ForeignKey("Customer")]
    public Guid CustomerId { get; set; }
    public virtual Customer Customer { get; set; } = null!;

    public virtual IEnumerable<Product>? Products { get; init; }
}
