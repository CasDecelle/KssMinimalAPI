﻿namespace Data.Entities;

public class Order
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid Id { get; set; }

    [Required]
    public DateTime CreatedAt { get; set; }

    [Required, ForeignKey("ShoppingCart")]
    public Guid ShoppingCartId { get; set; }
    public ShoppingCart ShoppingCart { get; set; } = null!;

    [Required, ForeignKey("PaymentMethod")]
    public int PaymentMethodId { get; set; }
    public virtual PaymentMethod PaymentMethod { get; set; } = null!;

    [Required, ForeignKey("ShippingAddress")]
    public Guid ShippingAddressId { get; set; }
    public virtual Address ShippingAddress { get; set; } = null!;

    [ForeignKey("InvoiceAddress")]
    public Guid InvoiceAddressId { get; set; }
    public virtual Address InvoiceAddress { get; set; } = null!;
}
