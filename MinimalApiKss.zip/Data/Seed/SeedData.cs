﻿namespace Data;

internal static class SeedData
{
    internal static readonly IEnumerable<PaymentMethod> PaymentMethods = new List<PaymentMethod>
    {
        new PaymentMethod
        {
            Id = 0,
            Value = "Bancontact",
        },
        new PaymentMethod
        {
            Id = 1,
            Value = "Visa",
        },
        new PaymentMethod
        {
            Id = 2,
            Value = "Mastercard",
        },
    };

    internal static readonly IEnumerable<Customer> Customers = new List<Customer>
    {
        new Customer
        {
            Id = Guid.Parse("3f9b57e9-0cee-41b7-ab84-473c606a0a14"),
            FirstName = "Jeff",
            LastName = "Mills",
        },
        new Customer
        {
            Id = Guid.Parse("0dac37e5-4156-4da0-b79f-bddb6b04cc21"),
            FirstName = "Charlotte",
            LastName = "de Witte",
        },
        new Customer
        {
            Id = Guid.Parse("9a7bae96-798d-4c92-9ae8-a735cd0630ba"),
            FirstName = "Ben",
            LastName = "Sims",
        },
        new Customer
        {
            Id = Guid.Parse("20674d17-e4ab-42dc-9dd7-91a89cb823e5"),
            FirstName = "Carl",
            LastName = "Cox",
        },
        new Customer
        {
            Id = Guid.Parse("a77ae063-a314-4efe-9794-97067bff78b2"),
            FirstName = "Amelie",
            LastName = "Lens",
        },
    };

    internal static readonly IEnumerable<Address> Addresses = new List<Address>
    {
        new Address
        {
            Id = Guid.Parse("b9ad6b5b-b6b3-42d7-840b-7a5d5e27cd3d"),
            Country = "USA",
            City = "Detroit",
            PostalCode = "1234",
            Street = "ClubStreet",
            Number = "7",
            Box = "1A",
            CustomerId = Customers.Single(x => x.Id == Guid.Parse("3f9b57e9-0cee-41b7-ab84-473c606a0a14")).Id,
        },
        new Address
        {
            Id = Guid.Parse("071783a6-a145-4f0a-b027-e649fa51f024"),
            Country = "Belgium",
            City = "Antwerp",
            PostalCode = "2018",
            Street = "AmpereStraat",
            Number = "97",
            Box = null,
            CustomerId = Customers.Single(x => x.Id == Guid.Parse("0dac37e5-4156-4da0-b79f-bddb6b04cc21")).Id,
        },
        new Address
        {
            Id = Guid.Parse("e32c56c0-fecd-4146-8158-b7b687a71065"),
            Country = "USA",
            City = "Los Angeles",
            PostalCode = "1234",
            Street = "ClubStreet",
            Number = "7",
            Box = "1A",
            CustomerId = Customers.Single(x => x.Id == Guid.Parse("0dac37e5-4156-4da0-b79f-bddb6b04cc21")).Id,
        },
        new Address
        {
            Id = Guid.Parse("14053372-3b08-4bcb-89b6-1ef5c6e61d28"),
            Country = "UK",
            City = "London",
            PostalCode = "N0L 1G0",
            Street = "Downing Street",
            Number = "10",
            Box = "123A",
            CustomerId = Customers.Single(x => x.Id == Guid.Parse("9a7bae96-798d-4c92-9ae8-a735cd0630ba")).Id,
        },
        new Address
        {
            Id = Guid.Parse("6c70d472-4ab4-4365-9cbb-1f9e2a8cab08"),
            Country = "USA",
            City = "Los Angeles",
            PostalCode = "90001",
            Street = "Hollywood Boulevard",
            Number = "43",
            Box = "12A",
            CustomerId = Customers.Single(x => x.Id == Guid.Parse("20674d17-e4ab-42dc-9dd7-91a89cb823e5")).Id,
        },
        new Address
        {
            Id = Guid.Parse("c91fd48d-13cd-472f-a50f-50b93453afce"),
            Country = "Spain",
            City = "Eivissa",
            PostalCode = "07800",
            Street = "Av. d'Agost",
            Number = "8",
            Box = null,
            CustomerId = Customers.Single(x => x.Id == Guid.Parse("20674d17-e4ab-42dc-9dd7-91a89cb823e5")).Id,
        },
        new Address
        {
            Id = Guid.Parse("b2987cf8-050b-4465-9b8e-dee77e35c666"),
            Country = "Belgium",
            City = "Brussels",
            PostalCode = "1000",
            Street = "Wetstraat",
            Number = "38",
            Box = null,
            CustomerId = Customers.Single(x => x.Id == Guid.Parse("a77ae063-a314-4efe-9794-97067bff78b2")).Id,
        },
    };

    internal static readonly IEnumerable<Product> Products = new List<Product>()
    {
        new Product
        {
            Id = Guid.Parse("6fa9c78b-f26c-48fd-9609-43b6b829c2c7"),
            Name = "LG C1 OLED55C16LA - 55 inch - 4K OLED - 2021",
            Price = 949m,
            Category = "Electronics",
            Company = "LG",
        },
        new Product
        {
            Id = Guid.Parse("17decf4e-c8b3-4486-b464-16278bc61ad6"),
            Name = "PHILIPS OLED 55 inch 55OLED837/12",
            Price = 1699m,
            Category = "Electronics",
            Company = "Philips",
        },
        new Product
        {
            Id = Guid.Parse("9e262241-921a-4f20-a0c8-0c2f8a6f64e4"),
            Name = "Eiffel Tower",
            Price = 629.99m,
            Category = "Toys",
            Company = "Lego",
        },
        new Product
        {
            Id = Guid.Parse("b8da7482-39e2-42f9-870f-c96f021d6402"),
            Name = "Hulk Buster",
            Price = 549.99m,
            Category = "Toys",
            Company = "Lego",
        },
        new Product
        {
            Id = Guid.Parse("49d0ad06-cff1-461d-80ef-3c24e2fe240c"),
            Name = "Cheff knife",
            Price = 79.95m,
            Category = "Cooking",
            Company = "Wusthoff",
        },
        new Product
        {
            Id = Guid.Parse("300f93aa-6c21-4eb4-960c-9d478ca72cd6"),
            Name = "Cheff's knife",
            Price = 74.95m,
            Category = "Cooking",
            Company = "Misen",
        },
    };
}
