﻿namespace MinimalApi.Products.Dtos;

public class ProductDto
{
    public Guid Id { get; init; }
    public string Name { get; init; }
    public decimal Price { get; init; }
    public string Category { get; init; }
    public string Company { get; init; }
}
