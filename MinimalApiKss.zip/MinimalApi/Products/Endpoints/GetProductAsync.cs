﻿using MinimalApi.Products.Dtos;
using MinimalApi.Products.Services;

namespace MinimalApi.Products.Endpoints;

public class GetProductAsync
{
    [ProducesResponseType(404)]
    [ProducesResponseType(200, Type = typeof(ProductDto))]
    public static async Task<IResult> Handle(Guid productId, IProductService productService)
    {
        var product = await productService.Get(productId);

        if (product == null)
        {
            return Results.NotFound();
        }

        return Results.Ok(product);
    }
}
