﻿using MinimalApi.Products.Dtos;
using MinimalApi.Products.Services;

namespace MinimalApi.Products.Endpoints;

public class GetProductsAsync
{
    [ProducesResponseType(200, Type = typeof(IEnumerable<ProductDto>))]
    public static async Task<IResult> Handle(IProductService productService)
    {
        var products = await productService.Get();

        return Results.Ok(products);
    }
}
