﻿using MinimalApi.Products.Dtos;
using MinimalApi.Products.Mappings;

namespace MinimalApi.Products.Services;

public interface IProductService
{
    Task<IEnumerable<ProductDto>> Get();
    Task<ProductDto> Get(Guid Id);
    Task<IEnumerable<ProductDto>> GetByCategory(string category);
}

public class ProductService : IProductService
{
    private readonly DatabaseContext _context;

    public ProductService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<ProductDto>> Get()
    {
        var products = await _context.Products.ToListAsync();

        return products.Select(product => product.MapToDto());
    }

    public async Task<ProductDto> Get(Guid id)
    {
        var product = await _context.Products.SingleAsync(p => p.Id == id);

        return product.MapToDto();
    }

    public async Task<IEnumerable<ProductDto>> GetByCategory(string category)
    {
        var products = await _context.Products.Where(p => p.Category == category).ToListAsync();

        return products.Select(p => p.MapToDto());
    }
}
