﻿using MinimalApi.Products.Endpoints;
using MinimalApi.Products.Services;

namespace MinimalApi.Products;

public class ProductsModule : IModuleWithEndpoints, IModuleWithServices
{
    public IServiceCollection RegisterServices(IServiceCollection services)
    {
        services.AddScoped<IProductService, ProductService>();

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        var productEndpoints = endpoints.MapGroup("products");
        productEndpoints.MapGet("", GetProductsAsync.Handle).WithName(nameof(GetProductsAsync));
        productEndpoints.MapGet("{productId}", GetProductAsync.Handle).WithName(nameof(GetProductAsync));

        return endpoints;
    }
}
