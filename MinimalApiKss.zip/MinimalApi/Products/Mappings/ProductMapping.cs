﻿using MinimalApi.Products.Dtos;

namespace MinimalApi.Products.Mappings;

public static class ProductsMapping
{
    public static Product MapToEntity(this ProductDto dto)
    {
        return new Product
        {
            Id = dto.Id,
            Name = dto.Name,
            Price = dto.Price,
            Category = dto.Category,
            Company = dto.Company,
        };
    }

    public static ProductDto MapToDto(this Product entity)
    {
        return new ProductDto
        {
            Id = entity.Id,
            Name = entity.Name,
            Price = entity.Price,
            Category = entity.Category,
            Company = entity.Company,
        };
    }
}
