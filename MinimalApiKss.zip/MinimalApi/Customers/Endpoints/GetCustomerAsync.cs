﻿using MinimalApi.Customers.Dtos;
using MinimalApi.Customers.Services;

namespace MinimalApi.Customers.Endpoints;

public static class GetCustomerAsync
{
    [ProducesResponseType(404)]
    [ProducesResponseType(200, Type = typeof(CustomerDto))]
    public static async Task<IResult> Handle(Guid customerId, ICustomerService customerService)
    {
        var customer = await customerService.GetCustomer(customerId);

        if (customer is null)
            Results.NotFound();

        return Results.Ok(customer);
    }
}
