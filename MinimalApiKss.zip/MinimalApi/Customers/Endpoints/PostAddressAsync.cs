﻿using MinimalApi.Customers.Dtos;
using MinimalApi.Customers.Services;

namespace MinimalApi.Customers.Endpoints;

public class PostAddressAsync
{
    [ProducesResponseType(400, Type = typeof(IEnumerable<string>))]
    [ProducesResponseType(200, Type = typeof(AddressDto))]
    public static async Task<IResult> Handle(AddressDto address, IValidator<AddressDto> validator, IAddressService addressService)
    {
        var validationResult = validator.Validate(address);

        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => e.ErrorMessage);
            return Results.BadRequest(errors);
        }

        var addedAddress = await addressService.Add(address);

        return Results.Ok(addedAddress);
    }
}
