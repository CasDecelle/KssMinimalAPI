﻿using MinimalApi.Customers.Dtos;
using MinimalApi.Customers.Services;

namespace MinimalApi.Customers.Endpoints;

public static class PostCustomerAsync
{
    [ProducesResponseType(200, Type = typeof(CustomerDto))]
    public static async Task<IResult> Handle(CustomerDto customer, IValidator<CustomerDto> validator, ICustomerService customerService)
    {
        var validationResult = validator.Validate(customer);

        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => e.ErrorMessage);
            return Results.BadRequest(errors);
        }

        var addedCustomer = await customerService.AddCustomer(customer);

        return Results.Ok(addedCustomer);
    }
}
