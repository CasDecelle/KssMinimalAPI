﻿namespace MinimalApi.Customers.Dtos;

public class AddressDto
{
    public Guid? Id { get; init; }
    public string? Country { get; init; }
    public string? City { get; init; }
    public string? PostalCode { get; init; }
    public string? Street { get; init; }
    public string? Number { get; init; }
    public string? Box { get; init; }
    public Guid? CustomerId { get; set; }
}
