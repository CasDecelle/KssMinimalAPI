﻿using MinimalApi.Customers.Endpoints;
using MinimalApi.Customers.Services;

namespace MinimalApi.Customers;

public class CustomerModule : IModuleWithEndpoints, IModuleWithServices
{
    public IServiceCollection RegisterServices(IServiceCollection services)
    {
        services.AddScoped<ICustomerService, CustomerService>();
        services.AddScoped<IAddressService, AddressService>();

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        var customerEndpoints = endpoints.MapGroup("customers");
        customerEndpoints.MapGet("{customerId}", GetCustomerAsync.Handle).WithName(nameof(GetCustomerAsync));
        customerEndpoints.MapPost("", PostCustomerAsync.Handle).WithName(nameof(PostCustomerAsync));

        var addressEndpoints = endpoints.MapGroup("addressess");
        addressEndpoints.MapPost("", PostAddressAsync.Handle).WithName(nameof(PostAddressAsync));

        return endpoints;
    }
}
