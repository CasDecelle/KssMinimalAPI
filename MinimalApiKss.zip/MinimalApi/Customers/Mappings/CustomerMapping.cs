﻿using MinimalApi.Customers.Dtos;

namespace MinimalApi.Customers.Mappings;

public static class CustomerMapping
{
    public static Customer MapToEntity(this CustomerDto dto)
    {
        return new Customer
        {
            Id = dto.Id ?? Guid.Empty,
            FirstName = dto.FirstName!,
            LastName = dto.LastName!,
            Addresses = dto.Addresses?.Select(address => address.MapToEntity()).ToList(),
        };
    }

    public static CustomerDto MapToDto(this Customer entity)
    {
        return new CustomerDto
        {
            Id = entity.Id,
            FirstName = entity.FirstName,
            LastName = entity.LastName,
            Addresses = entity.Addresses?.Select(address => address.MapToDto()).ToList(),
        };
    }
}
