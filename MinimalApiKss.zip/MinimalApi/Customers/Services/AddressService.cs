﻿using MinimalApi.Customers.Dtos;
using MinimalApi.Customers.Mappings;

namespace MinimalApi.Customers.Services;

public interface IAddressService
{
    Task<AddressDto> Add(AddressDto address);
}

public class AddressService : IAddressService
{
    private readonly DatabaseContext _context;

    public AddressService(DatabaseContext context)
    {
        _context = context;
    }

    public async Task<AddressDto> Add(AddressDto address)
    {
        var newAddress = _context.Add(address.MapToEntity());
        await _context.SaveChangesAsync();

        return newAddress.Entity.MapToDto();
    }
}
