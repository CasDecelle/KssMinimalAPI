﻿namespace MinimalApi.Common;

public class CommonModule : IModuleWithServices
{
    public IServiceCollection RegisterServices(IServiceCollection services)
    {
        services.AddSingleton<IDateTimeProvider, DateTimeProvider>();

        return services;
    }
}
