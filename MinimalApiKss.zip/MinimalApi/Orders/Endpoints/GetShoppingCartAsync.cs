﻿using MinimalApi.Orders.Dtos;
using MinimalApi.Orders.Services;

namespace MinimalApi.Orders.Endpoints;

public class GetShoppingCartAsync
{
    [ProducesResponseType(404)]
    [ProducesResponseType(200, Type = typeof(ShoppingCartDto))]
    public static async Task<IResult> Handle(Guid customerId, IShoppingCartService shoppingCartService)
    {
        var shoppingCart = await shoppingCartService.Get(customerId);

        if (shoppingCart == null)
        {
            return Results.NotFound();
        }

        return Results.Ok(shoppingCart);
    }
}
