﻿using MinimalApi.Orders.Dtos;
using MinimalApi.Orders.Services;

namespace MinimalApi.Orders.Endpoints;

public class GetOrdersByCustomerIdAsync
{
    [ProducesResponseType(200, Type = typeof(IEnumerable<OrderDto>))]
    public static async Task<IResult> Handle(Guid customerId, IOrderService orderService)
    {
        var orders = await orderService.GetByCustomerId(customerId);

        return Results.Ok(orders);
    }
}
