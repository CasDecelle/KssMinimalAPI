﻿using MinimalApi.Orders.Dtos;
using MinimalApi.Orders.Services;
using MinimalApi.Orders.Validators;

namespace MinimalApi.Orders.Endpoints;

public class PutShoppingCartAsync
{
    [ProducesResponseType(400, Type = typeof(IEnumerable<string>))]
    [ProducesResponseType(204)]
    public static async Task<IResult> Handle(ShoppingCartDto cart, IValidator<ShoppingCartDto> validator, IShoppingCartService shoppingCartService)
    {
        var validationResult = validator.Validate(cart, options => options.IncludeRuleSets(RuleSets.PutShoppingCart));

        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => e.ErrorMessage);
            return Results.BadRequest(errors);
        }

        await shoppingCartService.Update(cart);

        return Results.NoContent();
    }
}
