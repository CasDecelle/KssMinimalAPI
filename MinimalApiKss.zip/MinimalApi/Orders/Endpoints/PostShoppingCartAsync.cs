﻿using MinimalApi.Orders.Dtos;
using MinimalApi.Orders.Services;

namespace MinimalApi.Orders.Endpoints;

public class PostShoppingCartAsync
{
    [ProducesResponseType(400, Type = typeof(IEnumerable<string>))]
    [ProducesResponseType(200, Type = typeof(ShoppingCartDto))]
    public static async Task<IResult> Handle(ShoppingCartDto cart, IValidator<ShoppingCartDto> validator, IShoppingCartService shoppingCartService)
    {
        var validationResult = validator.Validate(cart);

        if (!validationResult.IsValid)
        {
            var errors = validationResult.Errors.Select(e => e.ErrorMessage);
            return Results.BadRequest(errors);
        }

        var shoppingCart = await shoppingCartService.Add(cart);

        return Results.Ok(shoppingCart);
    }
}
