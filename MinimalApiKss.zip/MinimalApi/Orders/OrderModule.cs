﻿using MinimalApi.Orders.Endpoints;
using MinimalApi.Orders.Services;

namespace MinimalApi.Orders;

public class OrderModule : IModuleWithEndpoints, IModuleWithServices
{
    public IServiceCollection RegisterServices(IServiceCollection services)
    {
        services.AddScoped<IShoppingCartService, ShoppingCartService>();
        services.AddScoped<IOrderService, OrderService>();

        return services;
    }

    public IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints)
    {
        var shoppingCartGroup = endpoints.MapGroup("carts");
        shoppingCartGroup.MapGet("{customerId}", GetShoppingCartAsync.Handle).WithName(nameof(GetShoppingCartAsync));
        shoppingCartGroup.MapPost("", PostShoppingCartAsync.Handle).WithName(nameof(PostShoppingCartAsync));
        shoppingCartGroup.MapPut("", PutShoppingCartAsync.Handle).WithName(nameof(PutShoppingCartAsync));

        var ordersGroup = endpoints.MapGroup("orders");
        ordersGroup.MapGet("{customerId}", GetOrdersByCustomerIdAsync.Handle).WithName(nameof(GetOrdersByCustomerIdAsync));
        ordersGroup.MapPost("", PostOrderAsync.Handle).WithName(nameof(PostOrderAsync));

        return endpoints;
    }
}
