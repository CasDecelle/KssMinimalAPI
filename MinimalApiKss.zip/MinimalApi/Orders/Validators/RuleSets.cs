﻿namespace MinimalApi.Orders.Validators;

internal class RuleSets
{
    internal const string PutShoppingCart = "PutShoppingCart";
}
