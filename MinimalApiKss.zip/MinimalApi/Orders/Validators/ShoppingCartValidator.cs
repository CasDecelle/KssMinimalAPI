﻿using MinimalApi.Orders.Dtos;

namespace MinimalApi.Orders.Validators;

public class ShoppingCartValidator : AbstractValidator<ShoppingCartDto>
{
    public ShoppingCartValidator()
    {
        RuleFor(cart => cart.CustomerId).NotNull().WithMessage("Shopping cart must have a customer");
        RuleFor(cart => cart.Products).NotEmpty().WithMessage("Shopping cart must have at least one product");

        RuleSet(RuleSets.PutShoppingCart, () =>
        {
            RuleFor(cart => cart.Id).NotNull().WithMessage("Shopping cart must have an Id");
            RuleFor(cart => cart.CreatedAt).NotNull().WithMessage("Shopping cart must have a creation date");
        });
    }
}
