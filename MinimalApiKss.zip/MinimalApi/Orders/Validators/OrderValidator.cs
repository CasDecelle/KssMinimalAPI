﻿using MinimalApi.Orders.Dtos;

namespace MinimalApi.Orders.Validators;

public class OrderValidator : AbstractValidator<OrderDto>
{
    public OrderValidator()
    {
        RuleFor(order => order.ShoppingCart).NotNull().DependentRules(() =>
        {
            RuleFor(order => order.ShoppingCart!.Products).NotEmpty().WithMessage("Order must have a shopping cart"); ;
        }).WithMessage("Order must have a shopping cart");
        RuleFor(order => order.InvoiceAddress).NotNull().WithMessage("Order must have an invoice address");
        RuleFor(order => order.ShippingAddress).NotNull().WithMessage("Order must have a shipping address");
        RuleFor(order => order.PaymentMethod).NotNull().WithMessage("Order must have a payment method");
    }
}
