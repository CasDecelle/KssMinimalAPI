﻿using MinimalApi.Orders.Dtos;
using MinimalApi.Orders.Mappings;
using MinimalApi.Products.Mappings;

namespace MinimalApi.Orders.Mappings;

public static class ShoppingCartMapping
{
    public static ShoppingCart MapToEntity(this ShoppingCartDto dto)
    {
        return new ShoppingCart
        {
            Id = dto.Id ?? Guid.Empty,
            CreatedAt = dto.CreatedAt!.Value,
            CustomerId = dto.CustomerId!.Value,
            Products = dto.Products?.Select(p => p.MapToEntity()),
        };
    }

    public static ShoppingCartDto MapToDto(this ShoppingCart entity)
    {
        return new ShoppingCartDto
        {
            Id = entity.Id,
            CreatedAt = entity.CreatedAt,
            CustomerId = entity.CustomerId,
            Products = entity.Products?.Select(p => p.MapToDto())
        };
    }
}
