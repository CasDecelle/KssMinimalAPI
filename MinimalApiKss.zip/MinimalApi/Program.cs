using MinimalApi;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<DatabaseContext>(
    dbContextOptions => dbContextOptions.UseSqlite(builder.Configuration.GetConnectionString("Sqlite"))
);

builder.Services.AddValidatorsFromAssemblyContaining<Program>();
builder.Services.AddServices();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.MapEndpoints();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.Run();
