﻿namespace MinimalApi;

public interface IModuleWithServices
{
    IServiceCollection RegisterServices(IServiceCollection services);
}

public interface IModuleWithEndpoints
{
    IEndpointRouteBuilder MapEndpoints(IEndpointRouteBuilder endpoints);
}

public static class ModuleExtensions
{
    public static IServiceCollection AddServices(this IServiceCollection services)
    {
        var modules = DiscoverModules<IModuleWithServices>();

        foreach (var module in modules)
        {
            module.RegisterServices(services);
        }

        return services;
    }

    public static WebApplication MapEndpoints(this WebApplication app)
    {
        var modules = DiscoverModules<IModuleWithEndpoints>();

        foreach (var module in modules)
        {
            module.MapEndpoints(app);
        }

        return app;
    }

    private static IEnumerable<T> DiscoverModules<T>()
    {
        return typeof(T).Assembly
            .GetTypes()
            .Where(p => p.IsClass && p.IsAssignableTo(typeof(T)))
            .Select(Activator.CreateInstance)
            .Cast<T>();
    }
}
